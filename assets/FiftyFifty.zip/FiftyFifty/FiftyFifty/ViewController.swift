//
//  ViewController.swift
//  FiftyFifty
//
//  Created by Caroline Amy Debs on 5/3/17.
//  Copyright © 2017 Caroline Amy Debs. All rights reserved.
//
import AVFoundation
import UIKit

class ViewController: UIViewController {
    
    var songPlaying = ""
    @IBOutlet weak var firstSong: UIButton!
    @IBOutlet weak var secondSong: UIButton!
    @IBOutlet weak var thirdSong: UIButton!

    
    @IBAction func play1(_ sender: Any) {
        playSound(songName: "TunnelVision")
        songPlaying = "Tunnel Vision"
    }
    @IBAction func play2(_ sender: Any) {
        playSound(songName: "Congratulations")
        songPlaying = "Congratulations"
    }
    @IBAction func play3(_ sender: Any) {
        playSound(songName: "Drowning")
        songPlaying = "Drowning"
    }
    @IBAction func pauseSong(_ sender: Any) {
        stopPlayer()
    }

    @IBAction func contSong(_ sender: Any) {
        player?.play()
    }

    var player: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func gotMail(_ sender: Any) {
        let when = DispatchTime.now() + 7
        DispatchQueue.main.asyncAfter(deadline: when) {
            let refreshAlert = UIAlertView()
            refreshAlert.title = "You Got REKT"
            refreshAlert.message = "Brad Sent You 'Friday' by Rebecca Black"
            refreshAlert.addButton(withTitle: "😂")
            refreshAlert.addButton(withTitle: "💩")
            refreshAlert.addButton(withTitle: "😡")
            refreshAlert.addButton(withTitle: "😎")
            refreshAlert.show()
            self.playSound(songName: "Friday")
        }
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func stopPlayer() {
        player?.stop();
    }
    
    func playSound(songName:String) {
        guard let sound = NSDataAsset(name: songName) else {
            print("asset not found")
            return
        }

        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(data: sound.data, fileTypeHint: AVFileTypeMPEGLayer3)
            player!.play()
            
        } catch let error as NSError {
            print("error: \(error.localizedDescription)")
        }
    }
}

